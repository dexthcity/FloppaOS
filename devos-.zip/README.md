# FloppaOS
the best os with big russian cat floppa

## About
This OS is made by some Russian guys, who likes nastoyashie vkusnie pelmeni v kotorih mnogo myasa i malo testa

## P.S
For further updates, you can simply run `git pull` and then repeat steps 2-5.
If the build is not successful after the update, try running `make clean`, and then try building again.

## Discord server
https://discord.gg/mCrPFtrQH8 - FloppaOS
