
 

#include <sys/stat.h>

mode_t umask( mode_t mask ) {
    /* TODO */
    return 0666;
}
