#include <unistd.h>

uid_t geteuid( void ) {
    return 0;
}
