#include <unistd.h>


int ftruncate( int fd, off_t length ) {
    /* TODO */

    printf( "TODO: ftruncate() not yet implemented!\n" );

    return -1;
}
