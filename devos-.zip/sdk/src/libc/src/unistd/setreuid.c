#include <unistd.h>

int setreuid( uid_t ruid, uid_t euid ) {
    return 0;
}
